config = {};

config.mailchimp_apikey = '304e2194acaf2b7639d6059a0eb87294-us8';
config.mailchimp_url = 'https://us8.api.mailchimp.com/3.0';
config.mailchimp_username = 'LaunchPadUSC';
config.mailchimp_list_id = 'b1093e9023';

module.exports = config;